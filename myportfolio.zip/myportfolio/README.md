# [Templatecookie](https://templatecookie.com)
Templatecookie.com creates quality templates and php scripts. Templatecookie has many free HTML & Figma templates available for professional use. Templatecookie is famous for its premium PHP Scripts available on [Codeanyon Marketplace](https://codecanyon.net/user/templatecookie). Browse [Templatecookie](https://templatecookie.com) today and discover awesome digital products.

# [Minimal - Personal Portfolio HTML Template](https://www.templatecookie.com/products)

> Minimal is a personal portfolio HTML template especially for UI/UX designer.

Check the [Live Demo here](https://minimal-personal-portfolio.netlify.app/).

![](screenshot.png)

## Pages List
- One Page Website (Landing Page)


## Framework & Technologies
- bootstrap
- scss
- fancy
- jQuery

## Credits
- Design & Developed by [Templatecookie](https://templatecookie.com)

## License
The MIT License (MIT). Please see [License File](LICENSE.md) for more information.

